import sys
import tweepy
import json
import MySQLdb as mdb
consumer_key="oNeZSSGb1bvZD156W3Cv9A"
consumer_secret="UApZt4Q4rufTsDmwaCfvQzDvhzF1nBOHmyB2UHbRxA"
access_key = "142917712-mgmfkAmPf9e5WQfYSsQfn0eCqhIAmDyorQNUYIBF"
access_secret = "IaMmeioBZNnEgllG4IHPd1evjaYzhRzhRq4Jv33v0" 

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_key, access_secret)
api = tweepy.API(auth)

for user in tweepy.Cursor(api.followers, screen_name="SardarHashim").items():
        print user.screen_name
